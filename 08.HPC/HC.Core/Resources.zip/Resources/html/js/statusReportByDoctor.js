$(document).ready(function () {
    
     (async function()
     {
         await CefSharp.BindObjectAsync("cefsharpBoundAsync");
         cefsharpBoundAsync.readyStatusReportDoctor();
         
     })();
    
   //  SetSite("");
   //  SetsiteStatusDtoJson("");
    // SetPERFORMCONTENT("");
 });
 
 
 function SetSite(json){
     var json ='{"ID":33,"SITE_ID":2600,"ESTIMATE_ID":0,"VISITDATE":"20200213","VISITRESERVEDATE":"20200213","SiteStatusDto":{"CURRENTWORKERCOUNT":1,"NEWWORKERCOUNT":1,"RETIREWORKERCOUNT":123,"CHANGEWORKERCOUNT":123,"ACCIDENTWORKERCOUNT":1,"DEADWORKERCOUNT":123,"INJURYWORKERCOUNT":213,"BIZDISEASEWORKERCOUNT":123,"GENERALHEALTHCHECKDATE":"2020-02-12","SPECIALHEALTHCHECKDATE":"2020-02-19","GENERALD2COUNT":123,"GENERALC2COUNT":1230,"SPECIALD1COUNT":123,"SPECIALC1COUNT":123,"SPECIALD2COUNT":123,"SPECIALC2COUNT":123,"SPECIALDNCOUNT":123,"SPECIALCNCOUNT":210,"WEMDATE":null,"WEMEXPORSURE":null,"WEMEXPORSUREREMARK":null,"WEMHARMFULFACTORS":"yhgfyj","RowStatus":0},"SITEMANAGERNAME":"2","SITEMANAGERGRADE":"1","DOCTORNAME":"3","ISDELETED":"N","MODIFIED":"2020-02-15T11:47:05.772987","MODIFIEDUSER":"41783","CREATED":"2020-02-13T13:15:46.33286","CREATEDUSER":"41783","RowStatus":0}'       
     console.log(json);
     var j = JSON.parse(json);
     console.log(j);
     console.log(j.SiteStatusDto);
  
     $('#siteName').text(j.SITENAME);
     $('#siteCEONAME').text(j.SITEOWENER);
     $('#siteAddress').text(j.SITEADDRESS);
     $('#siteTel').text("보건 담당자 연락처:"+j.SITETEL);
     $('#WORKERCOUNT').text("총원: "+j.WORKERCOUNT);
     
     
    // $('#WORKCONTENT').text("주요내용:"+ j.WORKCONTENT);
    // $('#OSHADATE').text("실시,예정일:"+j.OSHADATE+   "주요내용:"+j.OSHACONTENT); // 산업안전보건위원회
     
    
    $('#VISITDATE').text(j.VISITDATE.substring(0,4) +"년 " + j.VISITDATE.substring(4,6) +"월 "+ j.VISITDATE.substring(6,8) +"일");
    $('#SITEMANAGERGRADE').text(j.SITEMANAGERGRADE);
    $('#SITEMANAGERNAME').text(j.SITEMANAGERNAME);
    $('#VISITRESERVEDATE').text(j.VISITRESERVEDATE.substring(0,4) +"년 " + j.VISITRESERVEDATE.substring(4,6) +"월 "+ j.VISITRESERVEDATE.substring(6,8) +"일");
    $('#DOCTORNAME').text(j.DOCTORNAME);
 }
 
 //업무수행내역
 function SetPERFORMCONTENT(json){
    // var json ='{"mainContent":"567567","sDate":"20200205","sSupport":"Y","hCcount":"9","noiseD1":"100","noiseC1":"11","bunD1":"56","bunC1":"22","mD1":"5","mC1":null,"goldD1":"1","goldC1":"3",'
    // +'"etcD1":"13","etcC1":"3","aD1":"1","aC1":"2","bD1":"3","bC1":"4","cD1":"5","cC1":"5","dD1":"55","dC1":"22","eD1":"3","eC1":"3","ppCount":"91","ppa":"9","ppb":"8","ppc":null,"ppd":"4","qqCount":"9","qqContent":"gdfgdfg","chk1":"Y","chk2":"Y","chk3":"Y","chk4":"Y","chk4Content":"dfghdf","chk5":"Y","chk6":"Y","chk7":"Y","chk8":"Y","chk8Content":"dfg","chkContent":"346dgdf","chk10":"Y","chk11":"Y","chk12":"Y","chk13":"N","chk14":"Y","chk15":"Y","chk15Content":"567567","chk20":"Y","chk21":"Y","chk31":"Y","chk32":"Y","chk33":"Y","chk34":"Y","chk41":"Y","chk42":"Y","chk42Content":"23123","chk43":"Y","chk44":"Y","chk45":"Y","bogunRadio":"Y","bogun3":"11","bogun4":"567333","bogun5":"56766","bogun6":"567567","bogunchk1":"Y","bogunchk2":"Y","bogunchk3":"Y","bogunchk4":"Y","bogunchk5":"Y","bogunchk6":"Y","bogunchk6Content":"567567567","bogun7":"234234234234"}';
     var x = JSON.parse(json);
     $('#mainContent').text(x.mainContent);
     $('#sDate').text(x.sDate);
     if(x.sSupport=="Y"){
        $('#sSupport').prop('checked', true);
     }

     if(x.chk41=="Y"){ $('#chk41').prop('checked',true); }
     if(x.chk42=="Y"){ $('#chk42').prop('checked',true); }
     $('#chk42Content').text(x.chk42Content);
     if(x.chk43=="Y"){ $('#chk43').prop('checked',true); }
     if(x.chk44=="Y"){ $('#chk44').prop('checked',true); }
     if(x.chk45=="Y"){ $('#chk45').prop('checked',true); }

     //직업병건수
     $('#hCcount').text(x.hCcount);
     $('#noiseD1').text(x.noiseD1);
     $('#noiseC1').text(x.noiseC1);
     $('#bunD1').text(x.bunD1);
     $('#bunC1').text(x.bunC1);
     $('#mD1').text(x.mD1);
     $('#mC1').text(x.mC1);
     $('#goldD1').text(x.goldD1);
     $('#goldC1').text(x.goldC1);
     $('#etcD1').text(x.etcD1);
     $('#etcC1').text(x.getcC1);

     $('#aD1').text(x.aD1);
     $('#aC1').text(x.aC1);

     $('#bD1').text(x.bD1);
     $('#bC1').text(x.bC1);

     $('#cD1').text(x.cD1);
     $('#cC1').text(x.cC1);

     $('#dD1').text(x.dD1);
     $('#dC1').text(x.dC1);

     $('#eD1').text(x.eD1);
     $('#eC1').text(x.eC1);

     //조치지도
     if(x.chk1=="Y"){ $('#chk1').prop('checked',true); }
     if(x.chk2=="Y"){ $('#chk2').prop('checked',true); }
     if(x.chk3=="Y"){ $('#chk3').prop('checked',true); }
     if(x.chk4=="Y"){ $('#chk4').prop('checked',true); }
     $('#chk4Content').text(x.chk4Content);
     
     if(x.chk5=="Y"){ $('#chk5').prop('checked',true); }
     if(x.chk6=="Y"){ $('#chk6').prop('checked',true); }
     if(x.chk7=="Y"){ $('#chk7').prop('checked',true); }
     if(x.chk8=="Y"){ $('#chk8').prop('checked',true); }
     $('#chk8Content').text(x.chk8Content);

     $('#chkContent').text(x.chkContent);//이행확인결과
     //건강증진지도
     if(x.chk10=="Y"){ $('#chk10').prop('checked',true); }
     if(x.chh11=="Y"){ $('#chk11').prop('checked',true); }
     if(x.chk12=="Y"){ $('#chk12').prop('checked',true); }
     if(x.chk13=="Y"){ $('#chk13').prop('checked',true); }
     if(x.chk14=="Y"){ $('#chk14').prop('checked',true); }
     if(x.chk15=="Y"){ $('#chk15').prop('checked',true); }
     $('#chk15Content').text(x.chk15Content);
     if(x.chk20=="Y"){ $('#chk20').prop('checked',true); }
     if(x.chk21=="Y"){ $('#chk21').prop('checked',true); }
     
     //직업병관리
     if(x.chk31=="Y"){ $('#chk31').prop('checked',true); }
     if(x.chk32=="Y"){ $('#chk32').prop('checked',true); }
     if(x.chk33=="Y"){ $('#chk33').prop('checked',true); }
     if(x.chk34=="Y"){ $('#chk34').prop('checked',true); }

     //보건교육
     if(x.bogunRadio=="Y"){ 
        $('#bogunRadio_Y').prop('checked',true); 
     }else{
        $('#bogunRadio_N').prop('checked',true); 
     }
     $('#bogun3').text(x.bogun3); // 참석자
     $('#bogun4').text(x.bogun4);
     $('#bogun5').text(x.bogun5);
     $('#bogun6').text(x.bogun6);
     
     if(x.bogunchk1=="Y"){ $('#bogunchk1').prop('checked',true); }
     if(x.bogunchk2=="Y"){ $('#bogunchk2').prop('checked',true); }
     if(x.bogunchk3=="Y"){ $('#bogunchk3').prop('checked',true); }
     if(x.bogunchk4=="Y"){ $('#bogunchk4').prop('checked',true); }
     if(x.bogunchk5=="Y"){ $('#bogunchk5').prop('checked',true); }
     if(x.bogunchk6=="Y"){ $('#bogunchk6').prop('checked',true); }
     $('#bogunchk6Content').text(x.bogunchk6Content);
     $('#bogun7').text(x.bogun7);
     
     

     if(x.IsEdu=="Y"){
         $('#IsEdu_y').prop('checked', true); //보건교육실시 정기 = Y 기타 = N
     }else{
         $('#IsEdu_N').prop('checked', true);  //보건교육실시 정기 = Y 기타 = N
     }
     
 }
 //사업장현황
 function SetsiteStatusDtoJson(json){
     var json ='{"CURRENTWORKERCOUNT":100,"NEWWORKERCOUNT":2,"RETIREWORKERCOUNT":30,"CHANGEWORKERCOUNT":66,"ACCIDENTWORKERCOUNT":100,"DEADWORKERCOUNT":3,"INJURYWORKERCOUNT":13,"BIZDISEASEWORKERCOUNT":88,'
     +'"GENERALHEALTHCHECKDATE":"2020-02-05","SPECIALHEALTHCHECKDATE":"2020-02-14","GENERALD2COUNT":11,"GENERALC2COUNT":123,"SPECIALD1COUNT":142,"SPECIALC1COUNT":123,"SPECIALD2COUNT":44,"SPECIALC2COUNT":55,'
     +'"SPECIALDNCOUNT":66,"SPECIALCNCOUNT":77,"WEMDATE":"nsssll","WEMEXPORSURE":"N","WEMEXPORSUREREMARK":"3333333","WEMHARMFULFACTORS":"sss","RowStatus":0}';
     console.log(json);

     var x = JSON.parse(json);
     console.log(x);
     $('#CURRENTWORKERCOUNT').text(x.CURRENTWORKERCOUNT);
     $('#NEWWORKERCOUNT').text(x.NEWWORKERCOUNT);
     $('#RETIREWORKERCOUNT').text(x.RETIREWORKERCOUNT);
     $('#CHANGEWORKERCOUNT').text(x.CHANGEWORKERCOUNT);
     $('#ACCIDENTWORKERCOUNT').text(x.ACCIDENTWORKERCOUNT);
     $('#DEADWORKERCOUNT').text(x.DEADWORKERCOUNT);
     $('#INJURYWORKERCOUNT').text(x.INJURYWORKERCOUNT);
     $('#BIZDISEASEWORKERCOUNT').text(x.BIZDISEASEWORKERCOUNT);
     $('#GENERALHEALTHCHECKDATE').text(x.GENERALHEALTHCHECKDATE);
     $('#SPECIALHEALTHCHECKDATE').text(x.SPECIALHEALTHCHECKDATE);
     $('#GENERALD2COUNT').text(x.GENERALD2COUNT);
     $('#GENERALC2COUNT').text(x.GENERALC2COUNT);
     $('#SPECIALD1COUNT').text(x.SPECIALD1COUNT);
 
     $('#SPECIALD1COUNT').text(x.SPECIALC1COUNT);
     $('#SPECIALD2COUNT').text(x.SPECIALD2COUNT);
 
     $('#SPECIALC2COUNT').text(x.SPECIALC2COUNT);
     $('#SPECIALDNCOUNT').text(x.SPECIALDNCOUNT);
     $('#SPECIALCNCOUNT').text(x.SPECIALCNCOUNT);
 
     $('#WEMDATE').text(x.WEMDATE);
     $('#WEMEXPORSURE').text(x.WEMEXPORSURE);
     $('#WEMEXPORSUREREMARK').text(x.WEMEXPORSUREREMARK);
     $('#WEMHARMFULFACTORS').text(x.WEMHARMFULFACTORS);
     
     
     $('#WEMDATE').text("측정일: "+j.WEMDATE); 
     
     
     
     $('#WORKCONTENT').text("주요내용:"+ j.WORKCONTENT);
 
     $('#OSHADATE').text("실시,예정일:"+j.OSHADATE+   "주요내용:"+j.OSHACONTENT); // 산업안전보건위원회
     
     
 }
 
 function SetOpinion(html){
     $('#opinionSection').append(html);
 }
 function getCheck(val){
     if(val == "Y"){
         return '√';
     }else {
         return '-';
     }
 }