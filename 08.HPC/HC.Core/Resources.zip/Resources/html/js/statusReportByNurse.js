$(document).ready(function () {
   
    (async function()
    {
        await CefSharp.BindObjectAsync("cefsharpBoundAsync");
        cefsharpBoundAsync.readyStatusReportNurse();
        
    })();
   
    //SetSite("");
  // SetsiteStatusDtoJson("");
  // SetPERFORMCONTENT("");
});


function SetSite(json){
    var json ='{"ID":30,"SITE_ID":2600,"ESTIMATE_ID":0,"VISITDATE":"20200212","VISITRESERVEDATE":"20200211","SiteStatusDto":{"CURRENTWORKERCOUNT":100,"NEWWORKERCOUNT":2,"RETIREWORKERCOUNT":30,"CHANGEWORKERCOUNT":66,"ACCIDENTWORKERCOUNT":100,"DEADWORKERCOUNT":3,"INJURYWORKERCOUNT":13,"BIZDISEASEWORKERCOUNT":88,"GENERALHEALTHCHECKDATE":"2020-02-05","SPECIALHEALTHCHECKDATE":"2020-02-14","GENERALD2COUNT":11,"GENERALC2COUNT":123,"SPECIALD1COUNT":142,"SPECIALC1COUNT":123,"SPECIALD2COUNT":44,"SPECIALC2COUNT":55,"SPECIALDNCOUNT":66,"SPECIALCNCOUNT":77,"WEMDATE":null,"WEMEXPORSURE":"N","WEMEXPORSUREREMARK":"3333333","WEMHARMFULFACTORS":"drrrrrrrrrrrrrrrr","RowStatus":0},"SITEMANAGERNAME":"1","SITEMANAGERGRADE":"1","NURSENAME":"drtdrtdrt","ISDELETED":"N","MODIFIED":"2020-02-15T12:09:08.174202","MODIFIEDUSER":"41783","CREATED":"2020-02-12T20:58:16.439903","CREATEDUSER":"41783","RowStatus":0}'       
    var j = JSON.parse(json);
    console.log(j);
    console.log(j.SiteStatusDto);
   
   
    $('#VISITDATE').text(j.VISITDATE.substring(0,4) +"년 " + j.VISITDATE.substring(4,6) +"월 "+ j.VISITDATE.substring(6,8) +"일");
    $('#SITEMANAGERGRADE').text(j.SITEMANAGERGRADE);
    $('#SITEMANAGERNAME').text(j.SITEMANAGERNAME);
    $('#VISITRESERVEDATE').text(j.VISITRESERVEDATE.substring(0,4) +"년 " + j.VISITRESERVEDATE.substring(4,6) +"월 "+ j.VISITRESERVEDATE.substring(6,8) +"일");
    $('#NURSENAME').text(j.NURSENAME);
}

//업무수행내역
function SetPERFORMCONTENT(json){
    var json ='{"IsOshaPlan":"Y","IsOshaGeneral":"Y","IsMsds":"Y","IsMsdsInstall":"Y","IsMsdsSpeacial":"Y","IsHcPlan":"Y","IsHcManage":"Y","IsHcExplain"'
    +':"Y","IsDesease":"Y","IsDesease2":"Y","IsDeseaseCheck":"Y","IsDeseaseCheck2":"Y","IsEmergency":"Y","IsEmergencyManage":"Y","IsJobManage":"Y","IsJobManage2"'
    +':"Y","IsCommite":"Y","IsProtection1":"Y","IsProtection2":"Y","IsEdu":"Y","IsEduType":"Y","IsEduKind1":"Y","IsEduKind2":"Y","IsEduKind3":"Y","IsEduKind4":"Y"'
    +',"IsEduKind5":"Y","IsEduKind6":"Y","IsEduCount":"11","IsEduTitle":"1132123123","IsHealth1":"Y","IsHealth2":"Y","IsDe1":"Y","IsDe2":"Y","IsDe3":"Y",'
    +'"IsHe1":"Y","IsHe2":"Y","IsHe3":"Y","SangdamCount":1,"IsSangdam1":"Y","IsSangdam2":"Y","IsSangdam3":"Y","IsSangdam4":"Y","IsSangdam5":"Y","IsSangdam6":"Y",'
    +'"CheckCount1":12,"CheckCount2":2,"CheckCount3":33,"CheckCount4":23,"OshaData":"123123","RowStatus":0}';
    var x = JSON.parse(json);
    console.log(getCheck(x.IsOshaPlan))
    $('#IsOshaPlan').text(getCheck(x.IsOshaPlan));
    $('#IsOshaGeneral').text(getCheck(x.IsOshaGeneral));
    $('#IsMsds').text(getCheck(x.IsMsds));
    $('#IsMsdsInstall').text(getCheck(x.IsMsdsInstall));
    $('#IsMsdsSpeacial').text(getCheck(x.IsMsdsSpeacial));
    $('#IsHcPlan').text(getCheck(x.IsHcPlan));
    $('#IsHcManage').text(getCheck(x.IsHcManage));
    $('#IsHcExplain').text(getCheck(x.IsHcExplain));
    $('#IsDesease').text(getCheck(x.IsDesease));
    $('#IsDesease2').text(getCheck(x.IsDesease2));
    $('#IsDeseaseCheck').text(getCheck(x.IsDeseaseCheck));
    $('#IsDeseaseCheck2').text(getCheck(x.IsDeseaseCheck2));
    $('#IsEmergency').text(getCheck(x.IsEmergency));
    $('#IsEmergencyManage').text(getCheck(x.IsEmergencyManage));
    $('#IsJobManage').text(getCheck(x.IsJobManage));
    $('#IsJobManage2').text(getCheck(x.IsJobManage2));
    $('#IsCommite').text(getCheck(x.IsCommite));

    $('#IsProtection1').text(getCheck(x.IsProtection1));
    $('#IsProtection2').text(getCheck(x.IsProtection2));
    
    if(x.IsEdu=="Y"){
        $('#IsEdu_y').prop('checked', true); //보건교육실시 정기 = Y 기타 = N
    }else{
        $('#IsEdu_N').prop('checked', true);  //보건교육실시 정기 = Y 기타 = N
    }
    
    //$('#IsEduType').text(getCheck(x.IsEduType));
    if(x.IsEduKind1=="Y"){
        $('#IsEduKind1').prop('checked', true); 
    }
    if(x.IsEduKind2=="Y"){
        $('#IsEduKind2').prop('checked', true); 
    }
    if(x.IsEduKind3=="Y"){
        $('#IsEduKind3').prop('checked', true); 
    }
    if(x.IsEduKind4=="Y"){
        $('#IsEduKind4').prop('checked', true); 
    }
    if(x.IsEduKind5=="Y"){
        $('#IsEduKind5').prop('checked', true); 
    }
    if(x.IsEduKind6=="Y"){
        $('#IsEduKind6').prop('checked', true); 
    }
    
    $('#IsEduCount').text("참석자: " +x.IsEduCount +" 명");
    $('#IsEduTitle').text("주제: "+ x.IsEduTitle);

    $('#IsHealth1').text(getCheck(x.IsHealth1));
    $('#IsHealth2').text(getCheck(x.IsHealth2));
    $('#IsDe2').text(getCheck(x.IsDe2));
    $('#IsDe3').text(getCheck(x.IsDe3));
    $('#IsHe1').text(getCheck(x.IsHe1));
    $('#IsHe2').text(getCheck(x.IsHe2));
    $('#IsHe3').text(getCheck(x.IsHe3));

    $('#SangdamCount').text("•총 상담인원: "+ x.SangdamCount +" 명");
    console.log(x.IsSangdam1)
    if(x.IsSangdam1=="Y"){
        $('#IsSangdam1').prop('checked', true); 
    }
    if(x.IsSangdam2=="Y"){
        $('#IsSangdam2').prop('checked', true); 
    }
    if(x.IsSangdam3=="Y"){
        $('#IsSangdam3').prop('checked', true); 
    }
    if(x.IsSangdam4=="Y"){
        $('#IsSangdam4').prop('checked', true); 
    }
    if(x.IsSangdam5=="Y"){
        $('#IsSangdam5').prop('checked', true); 
    }
    if(x.IsSangdam6=="Y"){
        $('#IsSangdam6').prop('checked', true); 
    }
  
    console.log(x.CheckCount1)
    $('#CheckCount1').text("•혈압: " + x.CheckCount1 +" 건");
    $('#CheckCount2').text("•혈당: " + x.CheckCount2+" 건");
    $('#CheckCount3').text("•소변: " + x.CheckCount3+" 건");
    $('#CheckCount4').text("•체지방: " + x.CheckCount4+" 건");

    $('#OshaData').text(x.OshaData);
    

}
function SetsiteStatusDtoJson(json){
    var json ='{"CURRENTWORKERCOUNT":100,"NEWWORKERCOUNT":2,"RETIREWORKERCOUNT":30,"CHANGEWORKERCOUNT":66,"ACCIDENTWORKERCOUNT":100,"DEADWORKERCOUNT":3,"INJURYWORKERCOUNT":13,"BIZDISEASEWORKERCOUNT":88,'
    +'"GENERALHEALTHCHECKDATE":"2020-02-05","SPECIALHEALTHCHECKDATE":"2020-02-14","GENERALD2COUNT":11,"GENERALC2COUNT":123,"SPECIALD1COUNT":142,"SPECIALC1COUNT":123,"SPECIALD2COUNT":44,"SPECIALC2COUNT":55,'
    +'"SPECIALDNCOUNT":66,"SPECIALCNCOUNT":77,"WEMDATE":"aa","WEMEXPORSURE":"Y","WEMEXPORSUREREMARK":"3333333","WEMHARMFULFACTORS":"asd","RowStatus":0}';
    console.log(json);
    var x = JSON.parse(json);

    $('#CURRENTWORKERCOUNT').text(x.CURRENTWORKERCOUNT);
    $('#NEWWORKERCOUNT').text(x.NEWWORKERCOUNT);
    $('#RETIREWORKERCOUNT').text(x.RETIREWORKERCOUNT);
    $('#CHANGEWORKERCOUNT').text(x.CHANGEWORKERCOUNT);
    $('#ACCIDENTWORKERCOUNT').text(x.ACCIDENTWORKERCOUNT);
    $('#DEADWORKERCOUNT').text(x.DEADWORKERCOUNT);
    $('#INJURYWORKERCOUNT').text(x.INJURYWORKERCOUNT);
    $('#BIZDISEASEWORKERCOUNT').text(x.BIZDISEASEWORKERCOUNT);
    $('#GENERALHEALTHCHECKDATE').text(x.GENERALHEALTHCHECKDATE);
    $('#SPECIALHEALTHCHECKDATE').text(x.SPECIALHEALTHCHECKDATE);
    $('#GENERALD2COUNT').text(x.GENERALD2COUNT);
    $('#GENERALC2COUNT').text(x.GENERALC2COUNT);
    $('#SPECIALD1COUNT').text(x.SPECIALD1COUNT);

    $('#SPECIALD1COUNT').text(x.SPECIALC1COUNT);
    $('#SPECIALD2COUNT').text(x.SPECIALD2COUNT);

    $('#SPECIALC2COUNT').text(x.SPECIALC2COUNT);
    $('#SPECIALDNCOUNT').text(x.SPECIALDNCOUNT);
    $('#SPECIALCNCOUNT').text(x.SPECIALCNCOUNT);

    $('#WEMDATE').text(x.WEMDATE);
  
    $('#WEMEXPORSUREREMARK').text(x.WEMEXPORSUREREMARK);
    $('#WEMHARMFULFACTORS').text(x.WEMHARMFULFACTORS);

    
    
    if(x.WEMEXPORSURE=="Y"){
        $('#WEMEXPORSURE_Y').prop("checked", true);

    }else{
        $('#WEMEXPORSURE_N').prop("checked", true);
    }
    
    
    //$('#WORKCONTENT').text("주요내용:"+ j.WORKCONTENT);

    //$('#OSHADATE').text("실시,예정일:"+j.OSHADATE+   "주요내용:"+j.OSHACONTENT); // 산업안전보건위원회
   
}

function SetOpinion(html){
    $('#opinionSection').append(html);
}
function getCheck(val){
    if(val == "Y"){
        return '√';
    }else {
        return '-';
    }
}