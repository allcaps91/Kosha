$(document).ready(function () {
    (async function()
    {
        await CefSharp.BindObjectAsync("cefsharpBoundAsync");
        cefsharpBoundAsync.readyStatusReportEngineer();
        
    })();

});


function SetSite(json){
    console.log(json);
  //  var json ='{"ID":24,"SITE_ID":2600,"ESTIMATE_ID":0,"SITENAME":"(복)대구가톨릭사회복지회","SITEOWENER":"이문희","SITETEL":"tryrty55","SITEADDRESS":"대구중구 남산3동225-1호","VISITDATE":"20200206","VISITRESERVEDATE":"20200203","WORKERCOUNT":13,"WEMDATE":"20200210","WEMHARMFULFACTORS":null,"WEMEXPORSURE":"Y","WEMEXPORSUREREMARK":"33333333333333","WORKCONTENT":"3333333333","OSHADATE":"20200205","OSHACONTENT":"444444444","EDUTARGET":"55555","EDUAN":"7777777777777","EDUTITLE":"8888888888888888","SITEMANAGERNAME":"5555","SITEMANAGERGRADE":"sef","ENGINEERNAME":"sef","ISDELETED":"N","MODIFIED":"2020-02-15T14:24:07.835632","MODIFIEDUSER":"41783","CREATED":"2020-02-06T19:56:37.282875","CREATEDUSER":"41783","PERFORMCONTENT":null,"OPINION":"","RowStatus":0}'       
  
    var j = JSON.parse(json);
    console.log(j);
    $('#siteName').text(j.SITENAME);
    $('#siteCEONAME').text(j.SITEOWENER);
    $('#siteAddress').text(j.SITEADDRESS);
    $('#siteTel').text("보건 담당자 연락처:"+j.SITETEL);
    $('#WORKERCOUNT').text("총원: "+j.WORKERCOUNT);
    

   
    $('#WEMDATE').text("측정일: "+j.WEMDATE); 
    if(j.WEMEXPORSURE=="Y"){
        $('#WEMEXPORSURE').text("노출기준초과여부 : 미만"); 
    }else{
        $('#WEMEXPORSURE').text("노출기준초과여부 : 초과"); 
    }
    
    if(j.WORKCONTENT.length>0){
        $('#WORKCONTENT').text("주요내용:"+ j.WORKCONTENT);
    }
    

    $('#OSHADATE').text("실시,예정일:"+j.OSHADATE+   "주요내용:"+j.OSHACONTENT); // 산업안전보건위원회

    $('#EDUTARGET').text(j.EDUTARGET); //보건교육 대상
    $('#EDUPERSON').text(j.EDUPERSON) ;// 참석자
    $('#EDUAN').text(j.EDUAN) ;// 교안여부
    $('#EDUTITLE').text(j.EDUTITLE);//주제 
    

    
    $('#VISITDATE').text(j.VISITDATE.substring(0,4) +"년 " + j.VISITDATE.substring(4,6) +"월 "+ j.VISITDATE.substring(6,8) +"일");
    $('#SITEMANAGERGRADE').text(j.SITEMANAGERGRADE);
    $('#SITEMANAGERNAME').text(j.SITEMANAGERNAME);
    $('#VISITRESERVEDATE').text(j.VISITRESERVEDATE.substring(0,4) +"년 " + j.VISITRESERVEDATE.substring(4,6) +"월 "+ j.VISITRESERVEDATE.substring(6,8) +"일");
    $('#ENGINEERNAME').text(j.ENGINEERNAME);
    
}

function SetEDUTYPEJSON(json){
//보건교육종류//j.EDUTYPEJSON
    //var edu='{"ChkEduType1":"Y","ChkEduType2":"N","ChkEduType3":"N","ChkEduType4":"N","RowStatus":0}';
    var edu = JSON.parse(json);
    console.log(json);
   //  edu = JSON.parse(edu);
    if(edu.ChkEduType1=="Y"){ $('#ChkEduType1').prop('checked',true); }
    if(edu.ChkEduType2=="Y"){ $('#ChkEduType2').prop('checked',true); }
    if(edu.ChkEduType3=="Y"){ $('#ChkEduType3').prop('checked',true); }
    if(edu.ChkEduType4=="Y"){ $('#ChkEduType4').prop('checked',true); }
}
function SetEDUMETHODJSON(json){
    console.log(json);
     //보건교육 방법//EDUMETHODJSON
    //var temp = '{"ChkEduMethod1":"Y","ChkEduMethod2":"N","ChkEduMethod3":"N","RowStatus":0}';
    var temp = JSON.parse(json);
  // temp = JSON.parse(temp);
    if(temp.ChkEduMethod1=="Y"){ $('#ChkEduMethod1').prop('checked',true); }
    if(temp.ChkEduMethod2=="Y"){ $('#ChkEduMethod2').prop('checked',true); }
    if(temp.ChkEduMethod3=="Y"){ $('#ChkEduMethod3').prop('checked',true); }
    if(temp.ChkEduMethod4=="Y"){ $('#ChkEduMethod4').prop('checked',true); }
    
}

function SetENVCHECKJSON1(json){
  
    //작업환경점검 1
//    var json = '{"ENVCHECK1":"N","ENVCHECK2":"A","ENVCHECK3":"B","ENVCHECK4":"C","ENVCHECK5":"B","ENVCHECK6":"A","ENVCHECK7":"N","ENVCHECK8":"N","ENVCHECK9":"N","ENVCHECK10":"N","ENVCHECK11":"N","ENVCHECK12":"N","ENVCHECK13":"N","ENVCHECK14":"N","ENVCHECK15":"N","ENVCHECK16":"N","RowStatus":0}';
    var e = JSON.parse(json);
    console.log(e);
    $('#ENVCHECK1').text(getEnv(e.ENVCHECK1));
    $('#ENVCHECK2').text(getEnv(e.ENVCHECK2));
    $('#ENVCHECK3').text(getEnv(e.ENVCHECK3));
    $('#ENVCHECK4').text(getEnv(e.ENVCHECK4));
    $('#ENVCHECK5').text(getEnv(e.ENVCHECK5));
    $('#ENVCHECK6').text(getEnv(e.ENVCHECK6));
    $('#ENVCHECK7').text(getEnv(e.ENVCHECK7));
    $('#ENVCHECK8').text(getEnv(e.ENVCHECK8));
    $('#ENVCHECK9').text(getEnv(e.ENVCHECK9));
    $('#ENVCHECK10').text(getEnv(e.ENVCHECK10));
    $('#ENVCHECK11').text(getEnv(e.ENVCHECK11));
    $('#ENVCHECK12').text(getEnv(e.ENVCHECK12));
    $('#ENVCHECK13').text(getEnv(e.ENVCHECK13));
    $('#ENVCHECK14').text(getEnv(e.ENVCHECK14));
    $('#ENVCHECK15').text(getEnv(e.ENVCHECK15));
    $('#ENVCHECK16').text(getEnv(e.ENVCHECK16));
}
function SetENVCHECKJSON2(json){

    //작업환경점검 2    
    //var json ='{"ENVCHECK2_1":"N","ENVCHECK2_2":"N","ENVCHECK2_3":"N","ENVCHECK2_4":"A","ENVCHECK2_5":"A","ENVCHECK2_6":"A","ENVCHECK2_7":"N","ENVCHECK2_8":"N","ENVCHECK2_9":"N","ENVCHECK2_10":"N","ENVCHECK2_11":"N","ENVCHECK2_12":"N","ENVCHECK2_13":"N","ENVCHECK2_14":"N","ENVCHECK2_15":"N","ENVCHECK2_16":"N","ENVCHECK2_17":"N","ENVCHECK2_18":"N","ENVCHECK2_19":"N","ENVCHECK2_20":"N","ENVCHECK2_21":"N","ENVCHECK2_22":"N","ENVCHECK2_23":"N","ENVCHECK2_24":"N","ENVCHECK2_25":"N","ENVCHECK2_26":"N","ENVCHECK2_27":"N","ENVCHECK2_28":"N","ENVCHECK2_29":"N","ENVCHECK2_30":"N","ENVCHECK2_31":"N","ENVCHECK2_32":"N","ENVCHECK2_33":"N","ENVCHECK2_34":"N","ENVCHECK2_35":"N","ENVCHECK2_36":"N","ENVCHECK2_37":"N","ENVCHECK2_38":"N","ENVCHECK2_39":"N","RowStatus":0}';
    var e = JSON.parse(json);
    console.log(e);
    $('#ENVCHECK2_1').text(getEnv(e.ENVCHECK2_1));
    $('#ENVCHECK2_2').text(getEnv(e.ENVCHECK2_2));
    $('#ENVCHECK2_3').text(getEnv(e.ENVCHECK2_3));
    $('#ENVCHECK2_4').text(getEnv(e.ENVCHECK2_4));
    $('#ENVCHECK2_5').text(getEnv(e.ENVCHECK2_5));
    $('#ENVCHECK2_6').text(getEnv(e.ENVCHECK2_6));
    $('#ENVCHECK2_7').text(getEnv(e.ENVCHECK2_7));
    $('#ENVCHECK2_8').text(getEnv(e.ENVCHECK2_8));
    $('#ENVCHECK2_9').text(getEnv(e.ENVCHECK2_9));
    $('#ENVCHECK2_10').text(getEnv(e.ENVCHECK2_10));
    $('#ENVCHECK2_11').text(getEnv(e.ENVCHECK2_11));
    $('#ENVCHECK2_12').text(getEnv(e.ENVCHECK2_12));
    $('#ENVCHECK2_13').text(getEnv(e.ENVCHECK2_13));
    $('#ENVCHECK2_14').text(getEnv(e.ENVCHECK2_14));
    $('#ENVCHECK2_15').text(getEnv(e.ENVCHECK2_15));
    $('#ENVCHECK2_16').text(getEnv(e.ENVCHECK2_16));
    $('#ENVCHECK2_17').text(getEnv(e.ENVCHECK2_17));
    $('#ENVCHECK2_18').text(getEnv(e.ENVCHECK2_18));
    $('#ENVCHECK2_19').text(getEnv(e.ENVCHECK2_19));
    $('#ENVCHECK2_20').text(getEnv(e.ENVCHECK2_20));
    $('#ENVCHECK2_21').text(getEnv(e.ENVCHECK2_21));
    $('#ENVCHECK2_22').text(getEnv(e.ENVCHECK2_22));
    $('#ENVCHECK2_23').text(getEnv(e.ENVCHECK2_23));
    $('#ENVCHECK2_24').text(getEnv(e.ENVCHECK2_24));
    $('#ENVCHECK2_25').text(getEnv(e.ENVCHECK2_25));
    $('#ENVCHECK2_26').text(getEnv(e.ENVCHECK2_26));
    $('#ENVCHECK2_27').text(getEnv(e.ENVCHECK2_27));
    $('#ENVCHECK2_28').text(getEnv(e.ENVCHECK2_28));
    $('#ENVCHECK2_29').text(getEnv(e.ENVCHECK2_29));
    $('#ENVCHECK2_30').text(getEnv(e.ENVCHECK2_30));
    $('#ENVCHECK2_31').text(getEnv(e.ENVCHECK2_31));
    $('#ENVCHECK2_32').text(getEnv(e.ENVCHECK2_32));
    $('#ENVCHECK2_33').text(getEnv(e.ENVCHECK2_33));
    $('#ENVCHECK2_34').text(getEnv(e.ENVCHECK2_34));
    $('#ENVCHECK2_35').text(getEnv(e.ENVCHECK2_35));
    $('#ENVCHECK2_36').text(getEnv(e.ENVCHECK2_36));
    $('#ENVCHECK2_37').text(getEnv(e.ENVCHECK2_37));
    $('#ENVCHECK2_38').text(getEnv(e.ENVCHECK2_38));
    $('#ENVCHECK2_39').text(getEnv(e.ENVCHECK2_39));

}
function SetENVCHECKJSON3(json){

    //작업환경점검 3
    //var json ='{"ENVCHECK3_1":"N","ENVCHECK3_2":"N","ENVCHECK3_3":"N","ENVCHECK3_4":"N","ENVCHECK3_5":"N","ENVCHECK3_6":"B","ENVCHECK3_7":"N","ENVCHECK3_8":"N","ENVCHECK3_9":"N","ENVCHECK3_10":"N","ENVCHECK3_11":"N","ENVCHECK3_12":"N","ENVCHECK3_13":"C","ENVCHECK3_14":"N","ENVCHECK3_15":"N","ENVCHECK3_16":"N","ENVCHECK3_17":"N","ENVCHECK3_18":"N","ENVCHECK3_19":"N","ENVCHECK3_20":"N","ENVCHECK3_21":"N","ENVCHECK3_22":"N","ENVCHECK3_23":"A","ENVCHECK3_24":"N","ENVCHECK3_25":"N","ENVCHECK3_26":"N","ENVCHECK3_27":"N","ENVCHECK3_28":"N","ENVCHECK3_29":"N","ENVCHECK3_30":"N","ENVCHECK3_31":"B","ENVCHECK3_32":"N","ENVCHECK3_33":"N","RowStatus":0}'

    var e = JSON.parse(json);
    console.log(e);
    $('#ENVCHECK3_1').text(getEnv(e.ENVCHECK3_1));
    $('#ENVCHECK3_2').text(getEnv(e.ENVCHECK3_2));
    $('#ENVCHECK3_3').text(getEnv(e.ENVCHECK3_3));
    $('#ENVCHECK3_4').text(getEnv(e.ENVCHECK3_4));
    $('#ENVCHECK3_5').text(getEnv(e.ENVCHECK3_5));
    $('#ENVCHECK3_6').text(getEnv(e.ENVCHECK3_6));
    $('#ENVCHECK3_7').text(getEnv(e.ENVCHECK3_7));
    $('#ENVCHECK3_8').text(getEnv(e.ENVCHECK3_8));
    $('#ENVCHECK3_9').text(getEnv(e.ENVCHECK3_9));
    $('#ENVCHECK3_10').text(getEnv(e.ENVCHECK3_10));
    $('#ENVCHECK3_11').text(getEnv(e.ENVCHECK3_11));
    $('#ENVCHECK3_12').text(getEnv(e.ENVCHECK3_12));
    $('#ENVCHECK3_13').text(getEnv(e.ENVCHECK3_13));
    $('#ENVCHECK3_14').text(getEnv(e.ENVCHECK3_14));
    $('#ENVCHECK3_15').text(getEnv(e.ENVCHECK3_15));
    $('#ENVCHECK3_16').text(getEnv(e.ENVCHECK3_16));
    $('#ENVCHECK3_17').text(getEnv(e.ENVCHECK3_17));
    $('#ENVCHECK3_18').text(getEnv(e.ENVCHECK3_18));
    $('#ENVCHECK3_19').text(getEnv(e.ENVCHECK3_19));
    $('#ENVCHECK3_20').text(getEnv(e.ENVCHECK3_20));
    $('#ENVCHECK3_21').text(getEnv(e.ENVCHECK3_21));
    $('#ENVCHECK3_22').text(getEnv(e.ENVCHECK3_22));
    $('#ENVCHECK3_23').text(getEnv(e.ENVCHECK3_23));
    $('#ENVCHECK3_24').text(getEnv(e.ENVCHECK3_24));
    $('#ENVCHECK3_25').text(getEnv(e.ENVCHECK3_25));
    $('#ENVCHECK3_26').text(getEnv(e.ENVCHECK3_26));
    $('#ENVCHECK3_27').text(getEnv(e.ENVCHECK3_27));
    $('#ENVCHECK3_28').text(getEnv(e.ENVCHECK3_28));
    $('#ENVCHECK3_29').text(getEnv(e.ENVCHECK3_29));
    $('#ENVCHECK3_30').text(getEnv(e.ENVCHECK3_30));
    $('#ENVCHECK3_31').text(getEnv(e.ENVCHECK3_31));
    $('#ENVCHECK3_32').text(getEnv(e.ENVCHECK3_32));
    $('#ENVCHECK3_33').text(getEnv(e.ENVCHECK3_33));
}

function SetOpinion(html){
    $('#opinionSection').append(html);
}
function getEnv(val){
    if(val == "N"){
        return '해당없음';
    }else if(val == "A"){
        return "보통";
    }else if(val == "B"){
        return "양호";
    }else if(val == "C"){
        return "미흡";
    }
}